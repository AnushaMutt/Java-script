let x=10;
if(x%2==0){
console.log("even")
}
else
{
console.log("odd")
}

let y=10
let result=(10%2)==0?'even':'odd'
console.log(result)

var k=10
var j='10'
console.log(k==j)
console.log(k===j)