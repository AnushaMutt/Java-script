function breakfast(favFood='oats'){
console.log(`i love ${favFood} in breakfast`)
console.log('i love'+favFood+'in breakfast')
}
breakfast('maggi')
breakfast()
