let m1=90
let m2=80
let m3=40
let m4=80
let m5=90
var percentage=(m1+m2+m3+m4+m5)/500*100
if(percentage>=80)
{
console.log('a')
}
else if(percentage>=70)
{
console.log('b')}
else if(percentage>=60)
{
console.log('c')
}
else{
console.log('d')
}

let king="jayant"
if(true)
{
var king="ram"

}
console.log(king)
console.log(king)