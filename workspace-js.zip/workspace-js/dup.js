let employee={
eid:1001,
ename:'raj'}
let duplicateEmp={};
for(let key in employee){
duplicateEmp[key]=employee[key]
duplicateEmp.ename='kumar';
}
console.log(employee.ename)
console.log(duplicateEmp.ename)
console.log(duplicateEmp.eid)
