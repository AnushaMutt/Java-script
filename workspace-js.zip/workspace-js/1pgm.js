console.log('hello javascript')
let basic='5000'
let hra="2000"
let bonus='9000'
let salary=basic+hra+bon0us
console.log('salary')