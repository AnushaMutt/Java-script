let address={
house:101,
city:'bangalore'}

let person={
pid:1001,
pname:'abc',
address
}
console.log(person);