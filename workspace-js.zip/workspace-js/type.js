let s=true;
let s1="abc";
let s2=25;
console.log(typeof 0);
console.log(typeof null);
console.log(typeof (prompt));
console.log(typeof (alert));