let employee={
eid:1001,
ename:'raj'}
console.log(employee.eid);
let employee2={
e1id:employee.eid,
e1name:employee.ename}
console.log(employee2.e1id)