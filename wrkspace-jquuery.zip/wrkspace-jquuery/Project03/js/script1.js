$(function(){

//$("ul ul:first").prepend("<li>i love india</li>");
//$("ul ul:first").append("<li>i love india</li>");

//$("<li>2019 world champ</li>").prependTo($("ul ul:first"));
//$("<li>2019 world champ</li>").appendTo($("ul ul:first"));


//$("<li>2019 world champ</li>").prependTo($("ul ul"));

//$("<h1>2019 world champ<h1>").prependTo($ ("#content"));

//$("<p>cricketer</p>").prependTo($ (".green"));

//$(".red").after("<div class='red'>jadeja</div>");

//$(".green").before("<div class='green'>rahul</div>");

//$(".blue").before(function(){
//return "<div class='blue'>dravid</div>"

//});

//$(".blue").after($(".red"));

//$("li").replaceWith("<li>Replaced list</li>")


//$("li").replaceWith("<p>Replaced list</p>")

//$("li").replaceWith(function(){
//return "<p>dravid</p>"
//});



//$("li").replaceAll("<li>Replaced list</li>");

//$(".red,.blue").replaceWith($(".green"));


//$("form").children().not("input:text,textarea,br").remove();



//$(".red").remove();

//var detachedElement=$("li").detach();
//$("#content").append(detachedElement);

//$("p:first").empty();

/*var mylink=$("#mylink");
console.log(mylink.attr("href"))
mylink.attr("href","https://www.google.com");
console.log(mylink.attr("href"))*/


/*var textinput=$("input:text")
textinput.val("teju");
var rangeinput=$("input[type='range']")
console.log( rangeinput.val());
console.log( textinput.val());*/


/*var red=$(".red");
console.log(red.css('width'));
console.log(red.width());

red.css("background-color","pink");

$("p").css("font-size","20px");*/

var red=$(".red");

red.css("user-select",function(){
return "none";
});












});