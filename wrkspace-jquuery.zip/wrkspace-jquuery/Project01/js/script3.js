$(function(){
$(".red").fadeTo(2000,0);
$(".green").delay(4000).fadeOut(3000);
$(".blue").delay(6000).fadeOut(3000);


});