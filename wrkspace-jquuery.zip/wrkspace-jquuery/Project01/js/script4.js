$(function(){
$(".red").slideUp(3000);
$(".red").slideDown(3000);
$(".green").hide(5000);
$(".green").show(5000);

$("p").hide(5000);
$("p").show(5000);
$(".content").hide(5000);

});