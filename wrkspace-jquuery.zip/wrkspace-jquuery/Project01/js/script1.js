$(function(){
$(".red").fadeOut(3000);
$(".green").fadeOut(3000);
$(".red").fadeIn(3000);
});