$(function(){

$(".red").delay(1000).fadeOut(4000);
$(".green").delay(4000).fadeOut(4000);
$(".blue").delay(8000).fadeOut(4000);

$("h3").toggle();
$("#cnt").slideUp(2000);
$("h3").slideDown(5000);

$("p").delay(13000).animate(
{

"font-size":"25px",

},5000
);

});