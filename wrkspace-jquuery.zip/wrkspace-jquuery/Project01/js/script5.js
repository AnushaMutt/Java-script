$(function(){

$("p").hide(5000);
$("p").show(5000);
$("#content").hide(5000);

});