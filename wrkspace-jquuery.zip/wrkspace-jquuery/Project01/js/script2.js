$(function(){
$(".green").fadeTo(3000,0.2);
$(".blue").fadeToggle(3000);


});