$(function(){

$(".red").animate(
{
"margin-left":"200px",
"width":"20px",
"height":"20px",
"margin-top":"90px",
"opacity":"0.2"

},4000,"swing",
);

$("p").animate(
{

"font-size":"25px",

},5000
);



});