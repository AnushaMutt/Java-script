$(function(){


$("input[type='password']").css("background-color","orange");




$("p:even").css("background-color","pink");

$("p:odd").css("background-color","violet");


$("p:first").css("background-color","aqua");

$("p:last").css("background-color","yellow");


});