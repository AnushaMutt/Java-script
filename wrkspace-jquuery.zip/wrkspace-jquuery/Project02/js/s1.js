$(function(){
$("p").css("background-color","red");

$("#list").css("background-color","rgba(80,180,180,0.8)");

$("input").css("background-color","red");

$("input[type='password']").css("background-color","orange");


$("h1,h2,p,input").css("background-color","rgba(80,80,180,0.8)");


$("input[type='password']").css("background-color","orange");

});