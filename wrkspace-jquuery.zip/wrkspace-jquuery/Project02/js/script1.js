$(function(){

$("#list").find("li").css("background-color","orange");

});