$(function(){

$("h1,h2,p,input").css("background-color","rgba(80,80,180,0.8)");


$("input[type='password']").css("background-color","orange");

});